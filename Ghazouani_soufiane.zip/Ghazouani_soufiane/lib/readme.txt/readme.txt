Ce fichier “readme.txt/md” détaillera toute ressource extérieur au projet.

Un site web interactif qui permet de découvrir les actualités et articles autour des sports de combats.

.article-principal:first-of-type --> avec l'option flex:2 cela permet à la partie concernée de prendre 2x plus d'espace
que le secon

.article-principal:nth-of-type(2)-->par défaut il prendra le reste de l'espace disponible.

.sidebar --> permet de créer les barres latérales nécesaire pour notre formulaire.